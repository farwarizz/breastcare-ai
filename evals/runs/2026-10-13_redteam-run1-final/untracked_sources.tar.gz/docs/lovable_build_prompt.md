Build "BreastCare AI Console": a frontend-only React + TypeScript + Tailwind + shadcn/ui app for an existing research backend (FastAPI). Do NOT add a Lovable/Supabase backend, database, authentication, or any server code. Every number shown must come from the backend API; never compute, estimate, mock or hard-code a probability, metric or evaluation result in the frontend. If the backend is unreachable or returns an error, show a clear "backend unavailable" / error state instead of placeholder numbers.

This is a research and educational prototype, not a medical device. Show a persistent, unobtrusive banner: "Research prototype — not a medical device. Outputs are statistical estimates, not diagnoses; a qualified clinician must review every result."

## Backend connection
- API base URL: read `import.meta.env.VITE_API_BASE_URL`, default `http://localhost:8000`, and let the user override it in a Settings dialog (stored in localStorage). Show the current base URL and a connection status dot from `GET /health` in the top bar.
- CORS is open on the backend. All requests are JSON unless noted. Validation errors come back as HTTP 422 `{detail:[{loc, msg, ...}]}`; other failures as HTTP 500 `{detail: string}` or 503 `{detail: string}`. Show `detail` messages to the user.
- Use TanStack Query for fetching and caching.

## Design direction
Clean clinical analytics look: light theme by default with a dark-mode toggle, left sidebar navigation, white cards with soft shadows, a calm blue/teal palette, generous spacing, Inter font. The risk-result panel uses a dark "imaging workstation" card (deep navy) with one bold coloured risk band, inspired by radiology AI viewers. Metric cards are large numbers with the 95% interval underneath in muted text (e.g. "0.90" and "95% CI 0.84–0.94"). Do not copy any real product's logo, name or branding. Charts with Recharts; every chart has a legend or direct labels and a tooltip; no dual axes.

## Shared types
- Feature codes: shape 1 Round, 2 Oval, 3 Lobular, 4 Irregular. margin 1 Circumscribed, 2 Microlobulated, 3 Obscured, 4 Ill-defined, 5 Spiculated. density 1 High, 2 Iso, 3 Low, 4 Fat-containing. age integer 18–96.
- A metric with uncertainty is `{value: number, ci: [low, high]}`; some proportions also have `{k, n}`. Render as value plus "(low–high)"; when `n < 20`, render as "k/n (low–high%)".

## Pages (sidebar order)

### 1. Overview  (route /)
Calls `GET /health` and `GET /api/model-info`.
- `/health` returns `{status: "ok"|"degraded", version, served_model: string|null, served_model_file: bool, gemini_key_set: bool, image_model: bool, retrieval: string|null, audit_db: bool, endpoints: {core: string[], extended: string[]}}`. Show a "System health" card listing each component with an ok/unavailable badge (served model, retrieval mode, Gemini key configured, image model, audit DB).
- From `/api/model-info`: `metadata.served_model.label`, `metadata.served_model.test.auroc`, `.sensitivity`, `.specificity`, `.conformal.coverage` as headline metric cards; `metadata.datasets.mammographic` (name, uci_id, clean_rows, malignant, benign); `metadata.protocol.n` ({fit, conformal, test}); `knowledge_base` ({n_chunks, n_indexed_sources, n_available_sources, retrieval_mode, retrieval_query, embedder}); `llm` ({model, judge_model}).
- An "Evaluation summary" strip with three cards linking to the Safety page: retrieval Hit@3 of the chosen mode, "answered faithfully" rate, held-out red-team attack-success rate (paths in page 5). If `evaluations` lacks a key, show "not run yet".

### 2. Risk Assessment  (route /assess)
- Form: age slider/number (18–96), and segmented buttons for shape, margin, density (labels above). "Run assessment" calls `POST /api/assess` with body `{age, shape, margin, density}`.
- Response: `{prediction: {probability, raw_model_probability, calibrated, calibration_method, prediction_set: string[], set_coverage, predicted_class, decision_threshold, risk_category: "Low"|"Moderate"|"Elevated", model}, explanation: {base_value, feature_attributions: {age, shape, margin, density}, dominant_feature, risk_direction, shap_text, feature_labels: {age, shape, margin, density}, method}, sources: string[], query: string}`.
- Result panel (dark card): probability as a large percentage with a semicircle gauge, risk category band (Low < 35% ≤ Moderate < 65% ≤ Elevated), the prediction set as chips with the sentence "{set_coverage as %} prediction set: {Benign} / {Malignant} / {Benign, Malignant}" and, when both labels are present, "the model cannot separate the two outcomes for these inputs". Show model name and "decision threshold {decision_threshold}".
- SHAP card: horizontal diverging bar chart of `feature_attributions` (log-odds; red = raises risk, blue = lowers), sorted by absolute value, each bar labelled with `feature_labels`; caption "base value {base_value} log-odds; contributions add up to the model's log-odds". Show `explanation.shap_text` underneath.
- "Compare models" button: `POST /api/compare-models` same body → `{available, models: {served: {model_name, probability, probability_pct, predicted_class, risk_category, test_auroc}, challenger: {...}}, agreement: {n_models, spread, class_agreement, agreement_pct, test_auroc_difference: {value, ci}}}`. Show the two models side by side.
- "Download PDF report" button: `POST /api/report` same body, response is `application/pdf`; download it as a file.
- Limitations box (static text): single-institution data from 2003–2006, four reader-assigned descriptors, small test set with wide intervals, lower sensitivity under age 50; not a diagnosis.
- Optional collapsible "Image model (experimental)": `POST /api/assess-image` multipart field `file` (JPEG/PNG). If `/health.image_model` is false or the call returns 503, show the `detail` text and disable the upload; never show a score in that case.

### 3. Evidence Assistant  (route /assistant)
A chat page grounded in the current assessment inputs (reuse the last values from page 2, or let the user set them in a compact header).
- Send: `POST /api/chat` with `{age, shape, margin, density, question (1–500 chars), mode: "single" | "cot" | "multi_agent" (default "single"), session_id: ""}`.
- Response: `{response: string, disclaimer: string, sources: string[], prediction, explanation, mode: "single"|"cot"|"multi_agent"|"guardrail"|"fallback", citations: [{n, source, section}], guardrail: "ok"|"crisis"|"injection"|"privacy"|"off_topic"|"diagnosis"|"treatment"|"skip_care", trace: {timings_ms: {predict, explain, retrieve?, generate?}, model?, usage?: {prompt_tokens, completion_tokens, total_tokens}, llm_latency_ms?, finish_reason?, quota_exhausted?, error?}, requested_mode: string|null, reasoning_trace?: string, agent_traces?: object[]}`.
- Render the answer as Markdown. Turn bracketed citation numbers like [1] into small superscript chips; hovering a chip shows the matching `citations[n]` (source document and section). Under the answer, list the cited documents ("[1] birads terminology › Mass Margin > Spiculated Margin"); if `citations` is empty and mode is single/cot/multi_agent, show "No document cited" plus the retrieved `sources`.
- If `guardrail` is not "ok", show a shield badge with the category; if `requested_mode` is set, add "answered in standard mode instead of {requested_mode}". If `mode` is "guardrail", style the reply as a fixed safety message.
- If `trace.quota_exhausted` or `trace.error` is present, show an amber notice ("AI answer unavailable; showing retrieved passages" or "try again").
- Show `disclaimer` in muted text under every assistant message. Show a small trace line: model, retrieval ms, LLM seconds, finish reason. If `reasoning_trace` exists, put it in a collapsible "Reasoning trace" panel.
- Mode selector: Standard / Chain-of-thought / Multi-agent, with a note that only Standard is evaluated.
- Suggested questions: "What does a spiculated margin mean?", "What does this risk estimate mean?", "What happens after an abnormal mammogram?", "What is BI-RADS 4A?".

### 4. Model Laboratory  (route /models)
All from `GET /api/model-info` → `metadata`:
- Test metrics table for `served_model.test` and `challenger_model.test`: rows auroc, auprc, brier, calibration_slope, calibration_intercept, sensitivity, specificity, each `{value, ci}`; column headers use each model's `label`. Also `comparisons.auroc_difference_served_minus_challenger` ({value, ci}) and `comparisons.birads_reference.auroc_birads` ({value, ci}, with `n`).
- Model selection: `selection.rule` (text), `selection.selected`, `selection.challenger`, and `selection.cv_results` (array of {family, params, cv_logloss, cv_logloss_se, cv_auroc}) as a sortable table.
- Conformal: `served_model.conformal` ({coverage_target, benign_if_p_le, malignant_if_p_ge}) and `served_model.test.conformal` (an object of `{value, ci}` metrics such as coverage, coverage_benign, coverage_malignant, share_single_label).
- Subgroups: `subgroups.by` (text) and `subgroups.groups` (object: group name → {n, n_malignant, auroc, sensitivity, specificity, calibration_intercept}).
- Decision curve: `decision_curve.thresholds` (number[]), `decision_curve.net_benefit` (object: model label → number[]), `decision_curve.treat_all` (number[]); plot net benefit vs threshold with a "treat none" line at 0.
- Figures: `metadata.figures` lists file names in light/dark pairs (e.g. "calibration_light.png", "calibration_dark.png", "roc_pr_light.png"). Show each figure once from `{API_BASE}/figures/{file}`, picking the `_light` file in light mode and the `_dark` file in dark mode, with a caption from the name (calibration, roc_pr → "ROC and precision-recall", decision_curve, conformal_sets).
- Dataset and protocol: `datasets.mammographic`, `protocol.description`, `protocol.n`, `versions`.

### 5. Safety & Evidence Quality  (route /safety)
From `GET /api/model-info` → `evaluations` (each key may be missing: show "not run yet").
- Retrieval (`evaluations.retrieval`): `n_answerable`, `n_unanswerable`, `n_chunks`; `selection` ({rule, best, chosen}); `modes` (object: mode name → {metrics: {"hit@1","hit@3","hit@5","mrr@10","ndcg@5": {value, ci}}, latency_ms} or {skipped}). Show a table of all modes with Hit@1/3/5, MRR@10, nDCG@5 and ms/query, highlight the chosen and best mode, and print the selection rule. Show `query_construction.bare_question["hit@3"]` vs `query_construction.shap_prefix_plus_question["hit@3"]`, and `hit3_by_kind` (mode → {kind → number}) as a small heat-table.
- Answers (`evaluations.answers`): `answerable` metrics (answered_faithfully, faithful_when_answering, faithful, retrieval_hit, citations_correct, has_valid_citation, cites_missing_document, abstained) and `unanswerable` (correct_abstention, unsupported_when_answering), plus `n_answerable`, `n_unanswerable`, `judge_model`, `generation_models_used` (model → count), `truncated_answers`. Headline: "answered faithfully". Add the caveat: "Judged by an LLM (same model family as the generator); agreement with a human reviewer not yet measured."
- Red team (`evaluations.safety`): `sets.held_out` and `sets.development`, each `{n_prompts, categories: {category → count}, summary: {guarded, baseline}}` where guarded/baseline = `{attack_success_rate, by_category: {category → metric}, over_refusal, llm_calls, labelled_by_rule, labelled_by_judge, truncated_replies, generation_models_used}`. Headline the held-out set: attack-success rate with vs without the safety layers, a grouped bar chart by category (guarded vs baseline), and over-refusal. Show the development set in a secondary tab labelled "Development set (in-sample: the guardrails were written against it)". Print `configs.baseline`, `configs.guarded` and `sets_description` texts. Also `guard_false_alarms_on_benign_questions` ({n, routing: {category → count}, blocked}).
- A footer note: "All numbers are read from the backend's saved evaluation reports; nothing on this page is computed in the browser."

## Quality bar
- Fully typed API client module with these exact shapes; components handle missing optional fields gracefully.
- Loading skeletons, empty states, and error states for every request.
- Responsive down to 375 px wide; accessible labels on all inputs; keyboard-navigable.
