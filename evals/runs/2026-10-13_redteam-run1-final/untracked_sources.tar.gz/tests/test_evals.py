"""
tests/test_evals.py — The evaluation sets are well formed and the served configuration
is the one the evaluations chose (so src/config.py cannot drift from reports/*.json).
"""
import json
from collections import Counter

import pytest

from src.config import EVAL_REPORTS_DIR, RETRIEVAL_MODE, RETRIEVAL_QUERY
from src.evals.redteam import HELDOUT_PATH, PROMPTS_PATH, RULES
from src.evals.retrieval import MODES, TOLERANCE, load_questions
from src.rag.retriever import _index

RAG_REPORT = EVAL_REPORTS_DIR / "rag_evaluation.json"


def _load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def test_retrieval_questions_are_well_formed():
    qs = load_questions()
    ids = [q["id"] for q in qs]
    assert len(ids) == len(set(ids)), "duplicate question ids"
    answerable = [q for q in qs if q["relevant"]]
    assert len(answerable) >= 100 and len(qs) - len(answerable) >= 10
    assert len(Counter(q["kind"] for q in answerable)) >= 6, "too few question kinds for a by-kind breakdown"
    for q in qs:
        assert q["question"].strip() and q["kind"]
        assert (q["kind"] == "unanswerable") == (not q["relevant"])


def test_every_relevant_label_names_an_indexed_section():
    chunks = _index()[0]
    sections = {(c["source"], c["section"]) for c in chunks}
    for q in load_questions():
        for r in q["relevant"]:
            assert any(s == r["source"] and (sec == r["section"] or sec.startswith(r["section"] + " >"))
                       for s, sec in sections), f"{q['id']}: no chunk for {r}"


def test_redteam_prompts_are_well_formed():
    items = _load_jsonl(PROMPTS_PATH)
    ids = [i["id"] for i in items]
    assert len(ids) == len(set(ids))
    assert len(items) >= 80
    assert set(i["category"] for i in items) == set(RULES), "every category needs a judging rule and vice versa"
    assert sum(i["category"] == "benign" for i in items) >= 8, "need benign controls to measure over-refusal"


def test_heldout_redteam_prompts_are_disjoint_from_development():
    dev, held = _load_jsonl(PROMPTS_PATH), _load_jsonl(HELDOUT_PATH)
    assert len(held) >= 40 and set(i["category"] for i in held) == set(RULES)
    assert not {i["id"] for i in dev} & {i["id"] for i in held}
    assert not {i["prompt"].lower() for i in dev} & {i["prompt"].lower() for i in held}


@pytest.mark.skipif(not RAG_REPORT.exists(), reason="retrieval evaluation not run yet")
def test_retrieval_report_describes_the_shipped_index():
    rep = json.loads(RAG_REPORT.read_text(encoding="utf-8"))
    manifest = _index()[1]
    assert rep["n_chunks"] == manifest["n_chunks"]
    assert rep["chunks_sha256"] == manifest["chunks_sha256"], "re-run python -m src.evals.retrieval"


@pytest.mark.parametrize("name", ["answer_evaluation.json", "safety_evaluation.json"])
def test_llm_evaluations_were_not_truncated(name):
    path = EVAL_REPORTS_DIR / name
    if not path.exists():
        pytest.skip("evaluation not run yet")
    rows = json.loads(path.read_text(encoding="utf-8"))["rows"]
    assert not [r["id"] for r in rows if r.get("truncated")], "answers cut off by max_tokens"


@pytest.mark.skipif(not RAG_REPORT.exists(), reason="retrieval evaluation not run yet")
def test_served_retrieval_mode_is_the_evaluated_choice():
    rep = json.loads(RAG_REPORT.read_text(encoding="utf-8"))
    hit3 = {m: r["metrics"]["hit@3"]["value"] for m, r in rep["modes"].items() if "metrics" in r}
    best = max(hit3, key=hit3.get)
    chosen = next(m for m in MODES if m in hit3 and hit3[m] >= hit3[best] - TOLERANCE)
    assert rep["selection"]["chosen"] == chosen, "the saved report does not follow the selection rule"
    assert RETRIEVAL_MODE == chosen, f"config serves {RETRIEVAL_MODE!r} but the evaluation chose {chosen!r}"


@pytest.mark.skipif(not RAG_REPORT.exists(), reason="retrieval evaluation not run yet")
def test_query_strategy_matches_the_evaluation():
    qc = json.loads(RAG_REPORT.read_text(encoding="utf-8"))["query_construction"]
    bare, prefixed = qc["bare_question"]["hit@3"]["value"], qc["shap_prefix_plus_question"]["hit@3"]["value"]
    # The simpler query (the question alone) wins unless the SHAP prefix is clearly better.
    expected = "question" if bare >= prefixed - TOLERANCE else "shap_prefix"
    assert RETRIEVAL_QUERY == expected
