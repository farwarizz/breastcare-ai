"""
src/evals/common.py — Shared pieces for the LLM-based evaluations.

- Representative cases: answers are generated in the context of a realistic
  assessment, alternating a benign-looking and a suspicious case.
- judge(): asks JUDGE_MODEL for a JSON verdict and parses it robustly.
- wilson(): 95% Wilson score interval for a proportion (stable for small n
  and for rates near 0 or 1, unlike the normal approximation).
- Every LLM call is cached under evals/cache/, so a re-run spends no quota and
  anyone can recompute the reports from the committed cache.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from src.config import EVALS_DIR, JUDGE_MODEL

CACHE_DIR = EVALS_DIR / "cache"
CASES = [
    {"age": 45, "shape": 1, "margin": 1, "density": 3},   # benign-looking
    {"age": 66, "shape": 4, "margin": 5, "density": 3},   # suspicious
]


def case_for(index: int) -> dict:
    return CASES[index % len(CASES)]


def load_jsonl(path: Path) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def parse_json(text: str) -> dict:
    """First JSON object in a model reply (tolerates code fences and prose)."""
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            raise
        return json.loads(m.group(0))


def judge(system: str, user: str, cache_name: str) -> dict:
    from src.llm.client import complete
    res = complete([{"role": "user", "content": user}], system, model=JUDGE_MODEL,
                   max_tokens=400, temperature=0.0, json_mode=True,
                   cache_path=CACHE_DIR / cache_name, wait_on_rate_limit=True)
    return parse_json(res.text)


def wilson(k: int, n: int, z: float = 1.96) -> dict:
    if n == 0:
        return {"value": None, "ci": [None, None], "k": 0, "n": 0}
    p = k / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return {"value": round(p, 4), "ci": [round(max(0.0, centre - half), 4), round(min(1.0, centre + half), 4)],
            "k": k, "n": n}
