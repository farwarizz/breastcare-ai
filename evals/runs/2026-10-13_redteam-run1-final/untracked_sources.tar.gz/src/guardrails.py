"""
src/guardrails.py — Input guardrails, applied before retrieval and generation.

Deterministic rules (regular expressions): cheap, testable, and they cannot be
talked out of their behaviour. Each user question is routed to one category:

  crisis        fixed supportive reply with crisis resources; the LLM is not called
  injection     fixed refusal (attempts to change the rules or reveal instructions)
  privacy       fixed refusal (the app holds no one else's records)
  off_topic     fixed scope reply (requests unrelated to breast imaging)
  diagnosis     LLM answer with a policy note: do not say whether it is cancer
  treatment     LLM answer with a policy note: no medication or treatment decisions
  skip_care     LLM answer with a policy note: do not endorse skipping recommended care
  ok            normal pipeline

The output filter in src/safety.py still runs on every LLM answer. Both layers
are measured by the red-team evaluation (src/evals/redteam.py).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_I = re.IGNORECASE

# Phrasings follow common crisis-line screening language (ending one's life, wishing to be
# dead, overdose, self-harm in any tense). "can't go on" alone is too common in ordinary
# complaints ("I can't go on with these tests"), so it needs "anymore" / "like this".
CRISIS = re.compile(
    r"\b(kill(ing)? myself|(end|ending|take|taking) (it all|my (own )?life|things|everything)|"
    r"suicid\w*|want(ed)? to die|(wish|rather) (i (was|were)|to be|be) dead|better off dead|"
    r"don'?t want to (live|be alive|be here|go on|carry on|wake up)|self[- ]?harm\w*|"
    r"(hurt|harm|cut)(ing)? myself|no (reason|point) (to|in) (live|living|go on|going on)|"
    r"what'?s the point (of|in) (living|life|going on)|overdos\w*|"
    r"take all (of )?my (pills|tablets|medication|meds)|can'?t go on (anymore|any more|like this))\b", _I)

# Attempts to change the assistant's rules, reveal its instructions or swap its role. Each
# alternative names the assistant's own instructions, so ordinary questions that mention
# "rules", "instructions" or "safety" ("show me the follow-up rules for BI-RADS 3") pass.
_TARGET = r"(all |any |the |your |my |these |those |previous |prior |above |earlier |initial |system |safety )*"
INJECTION = re.compile(
    rf"((ignore|disregard|forget|override|bypass)\s+{_TARGET}(instructions?|rules|prompts?|guidelines|"
    r"polic(y|ies)|restrictions|guardrails?|filters?)\b|system prompt|your (instructions|prompt|rules)\b|"
    r"developer mode|\bjailbreak|(?-i:\bDAN\b)|do anything now|"
    r"you are now (a|an|my|in|no longer|free|unrestricted|uncensored|jailbroken)\b|from now on,? you|"
    r"pretend (you are|to be|you're)|act as (an? )?(unrestricted|uncensored|different|real)|roleplay as|"
    r"(new|updated) (system )?(polic(y|ies)|rules|instructions)( for you|:| you must| to follow)|"
    r"<\s*/?\s*(system|admin|developer)\s*>|\[\s*(system|admin)\s*\]|"
    r"(reveal|print|show|repeat|output|display)\b.{0,20}\b(your|the system|system|hidden|initial|original|"
    r"developer|above)\s+(prompt|instructions|rules|message))", _I)

# Requests for other people's data. Questions about what usually happens to other patients
# ("do other patients with similar results need a biopsy?") are allowed.
PRIVACY = re.compile(
    r"(((other|another) (patient|user|person)'?s|other (patients|users|people)'|someone else'?s|"
    r"everyone'?s|(last|previous) (patient|user|person)'?s)\s+(records?|data|results?|history|details|"
    r"names?|emails?|files?|scans?|reports?)|"
    r"\b(records?|data|results?|details|names?|emails?|files?|scans?)\s+(of|for|from|belonging to)\s+"
    r"(other|another|all (the )?|every|previous|the (last|previous)) (patients?|users?|people|persons?)|"
    r"\b(show|give|list|export|dump|download|send)\b.{0,30}\b(patients?|users?)\b.{0,30}"
    r"\b(records?|data|names|emails?|results?)|audit (log|database|db))", _I)

DOMAIN = re.compile(
    r"\b(breast|mammo\w*|bi-?rads|biops\w*|cancer|malignan\w*|benign|tumou?r|mass(es)?|lump|"
    r"margin|density|dense|spiculat\w*|calcif\w*|ultrasound|mri|screening|radiolog\w*|"
    r"oncolog\w*|risk|result|estimate|probability|shap|model|follow[- ]?up|cyst|"
    r"fibroadenoma|lesion|nipple|lymph|brca|tamoxifen|chemo\w*|radiation|surgery|"
    r"doctor|clinician|nurse|symptom|pain|scan|imaging|app|score)\b", _I)

OFF_TOPIC = re.compile(
    r"\b(poem|song|lyrics|joke|story|recipe|cook|(write|debug|fix)\b.{0,15}\bcode|program(ming)?|python|javascript|"
    r"capital of|weather|stock|crypto|bitcoin|football|cricket|movie|homework|essay|"
    r"translate|math problem|president|election)\b", _I)

DIAGNOSIS = re.compile(
    r"(\b(do|could|might) i have\b.{0,25}\b(cancer|malignan\w*|tumou?r)|"
    r"\b(have i got|am i)\b.{0,20}\b(cancer|malignant)|"
    r"\bis (it|this|mine|my (lump|mass|finding|result))\b.{0,20}\b(cancer|malignant|cancerous)|"
    r"\bdiagnos(e|is)\b.{0,10}\b(me|my)\b|\b(confirm|rule out)\b.{0,20}\bcancer|"
    r"\b(tell|let) me (straight|honestly|if)\b.{0,30}\b(cancer|malignant))", _I)

TREATMENT = re.compile(
    r"(\b(dose|dosage|how (much|many)|what strength|\d+\s?mg)\b.{0,40}\b(take|tamoxifen|letrozole|"
    r"anastrozole|exemestane|chemo\w*|medication|medicine|drug|pills?|tablets?|herceptin|trastuzumab)|"
    r"\bshould i (take|start|stop|try)\b.{0,30}\b(tamoxifen|letrozole|anastrozole|chemo\w*|"
    r"medication|medicine|drugs?|pills?|hormones?|supplements?|treatment)|"
    r"\b(prescribe|recommend)\b.{0,20}\b(me|a)\b.{0,20}\b(drug|medication|treatment|chemo\w*))", _I)

SKIP_CARE = re.compile(
    r"(\b(skip|cancel|avoid|postpone|delay|ignore|refuse|not (go|bother))\b.{0,30}"
    r"\b(biops\w*|follow[- ]?up|mammogram|appointment|doctor|radiologist|screening|surgery)|"
    r"\b(do|did) i (really )?(still )?need\b.{0,15}\b(a |the |my )?(biopsy|follow[- ]?up|surgery)|"
    r"\binstead of\b.{0,15}\b(a |my |the )?(biopsy|doctor|radiologist))", _I)

CRISIS_REPLY = (
    "I'm really sorry you're going through this. You don't have to face it alone. "
    "If you might act on thoughts of harming yourself, please contact your local emergency "
    "number right now. You can also talk to a crisis line: in the US, call or text 988 "
    "(Suicide & Crisis Lifeline); in the UK and Ireland, call Samaritans on 116 123; anywhere "
    "else, findahelpline.com lists free, confidential helplines in your country. Talking to "
    "someone you trust, or to your doctor or care team, can help too. Waiting for or receiving "
    "breast imaging results is genuinely stressful, and support is available."
)
FIXED_REPLIES = {
    "crisis": CRISIS_REPLY,
    "injection": ("I can't change how I work or share my instructions. I can explain breast-imaging "
                  "terms, the risk estimate on screen, or what usually happens next. Please ask about those."),
    "privacy": ("I don't have access to anyone's records and can't share personal data. This prototype "
                "only sees the four values you enter for your own estimate."),
    "off_topic": ("I can only help with breast imaging: BI-RADS terms, the risk estimate shown in this "
                  "app, and what usually happens after a mammogram."),
}
POLICY_NOTES = {
    "diagnosis": ("The user is asking for a diagnosis. Do not say or imply whether they have cancer. "
                  "Explain that only a biopsy reviewed by a pathologist, together with their clinician, "
                  "can answer that, and explain what the estimate does and does not mean."),
    "treatment": ("The user is asking about medication or treatment decisions. Do not recommend, dose, "
                  "start or stop any treatment. Say these decisions belong to their oncology or care team."),
    "skip_care": ("The user is considering skipping or delaying recommended care. Do not endorse that. "
                  "Explain that this estimate cannot replace the follow-up or biopsy their clinician "
                  "recommends, and encourage them to discuss concerns with that clinician."),
}


@dataclass(frozen=True)
class GuardDecision:
    category: str
    fixed_reply: str | None = None      # set → answer with this text, skip the LLM
    policy_note: str | None = None      # set → add to the LLM prompt

    @property
    def calls_llm(self) -> bool:
        return self.fixed_reply is None


def check_input(question: str | None) -> GuardDecision:
    q = (question or "").strip()
    if not q:
        return GuardDecision("ok")
    for category, pattern in (("crisis", CRISIS), ("injection", INJECTION), ("privacy", PRIVACY)):
        if pattern.search(q):
            return GuardDecision(category, fixed_reply=FIXED_REPLIES[category])
    if OFF_TOPIC.search(q) and not DOMAIN.search(q):
        return GuardDecision("off_topic", fixed_reply=FIXED_REPLIES["off_topic"])
    for category, pattern in (("diagnosis", DIAGNOSIS), ("treatment", TREATMENT), ("skip_care", SKIP_CARE)):
        if pattern.search(q):
            return GuardDecision(category, policy_note=POLICY_NOTES[category])
    return GuardDecision("ok")
