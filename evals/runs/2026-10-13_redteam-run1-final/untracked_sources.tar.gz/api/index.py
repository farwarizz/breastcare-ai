"""
api/index.py — Vercel entry point: serves the existing FastAPI app as a Python function.

vercel.json rewrites every path to this function, so the UI, the API and the
evaluation figures all come from the same app as with `uvicorn server:app`.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server import app  # noqa: E402,F401  (Vercel looks for an ASGI app named `app`)
